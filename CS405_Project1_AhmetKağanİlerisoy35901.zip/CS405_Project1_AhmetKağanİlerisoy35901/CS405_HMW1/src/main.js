/**
 * Entry point: wires GPU, painting, camera, scene and UI together and runs
 * the render loop. You will edit this file a little (camera controls, views);
 * most of your work goes into src/math/ and src/scene/.
 *
 *   p_clip = P · V · M · p_object
 */
import './ui/style.css';
import { initWebGPU, showFatal } from './render/gpu.js';
import { Renderer } from './render/renderer.js';
import { Painting } from './render/painting.js';
import {
  createCamera, createInspectionCamera, viewProjection, pickPaintingPlane, frustumLines,
} from './scene/camera.js';
import { createScene } from './scene/scene.js';
import { createPanel } from './ui/panel.js';
import { Stats } from './ui/stats.js';
import { attachPointer } from './ui/input.js';
import { PAINTINGS, DEFAULT_PAINTING, paintingURL } from './config.js';
import * as mat4 from './math/mat4.js';

const ORBIT_START = { radius: 2.8, azimuth: 0, elevation: 0 };
const INSPECT_START = { radius: 4.5, azimuth: 1.0, elevation: 0.35 };

async function main() {
  const canvas = document.getElementById('gfx');
  const gpu = await initWebGPU(canvas);
  const renderer = new Renderer(gpu);
  const painting = new Painting(gpu);

  const params = new URLSearchParams(location.search);
  let current = PAINTINGS.find((p) => p.id === params.get('painting'))
    ?? PAINTINGS.find((p) => p.id === DEFAULT_PAINTING);
  await painting.load(paintingURL(current));

  /* ---------------- UI ---------------- */
  const panelRoot = document.getElementById('panel');
  const panel = createPanel(panelRoot);
  const title = document.createElement('h1');
  title.textContent = 'CS405 · Project 1';
  panelRoot.appendChild(title);
  const stats = new Stats(panelRoot);

  const pf = panel.folder('Painting');
  pf.select('painting', PAINTINGS.map((p) => ({ value: p.id, label: `${p.artist} — ${p.title}` })), current.id,
    async (id) => {
      current = PAINTINGS.find((p) => p.id === id);
      await painting.load(paintingURL(current));
      history.replaceState(null, '', `?painting=${id}`);
    });

  const camera = createCamera();
  const inspection = createInspectionCamera();
  const orbit = { ...ORBIT_START };
  const insOrbit = { ...INSPECT_START };
  const view = { which: 'split', frustum: true };

  function placeEye(cam, o) {
    const t = cam.target;
    const r = o.radius;
    const az = o.azimuth;
    const el = o.elevation;
    cam.eye = [
      t[0] + (r * Math.cos(el) * Math.sin(az)),
      t[1] + (r * Math.sin(el)),
      t[2] + (r * Math.cos(el) * Math.cos(az)),
    ];
  }
  const updateEye = () => placeEye(camera, orbit);
  placeEye(inspection, insOrbit);

  const vf = panel.folder('View');
  const viewSelect = vf.select('view', [
    { value: 'split', label: 'side by side'},
    { value: 'main', label: 'main camera only' },
    { value: 'inspection', label: 'inspection camera only' },
  ], view.which, (v) => (view.which = v));
  const frustumToggle = vf.toggle('draw main camera frustum', view, 'frustum');
  vf.button('reset scene and camera', resetAll);
  vf.note(gpu.encodeSRGB ? 'sRGB: encoded in shader (fallback)' : 'sRGB: canvas -srgb view');

  const cf = panel.folder('Camera');
  const camStatus = cf.text('');
  const projSelect = cf.select('projection', ['perspective', 'orthographic'], camera.projection, (v) => (camera.projection = v));
  const camSliders = [
    cf.slider('fovY (rad)', camera, 'fovY', 0.3, 1.8, 0.01),
    cf.slider('near', camera, 'near', 0.05, 2, 0.01),
    cf.slider('far', camera, 'far', 3, 100, 0.5),
  ];
  
  
  const camReadout = cf.text('');

  const scene = createScene({ gpu, renderer, painting, panel, paintingId: () => current.id });

  function resetAll() {
    Object.assign(camera, createCamera());
    Object.assign(orbit, ORBIT_START);
    Object.assign(insOrbit, INSPECT_START);
    Object.assign(view, { which: 'split', frustum: true });
    updateEye();
    placeEye(inspection, insOrbit);
    viewSelect.set(view.which);
    projSelect.set(camera.projection);
    frustumToggle.update();
    camSliders.forEach((s) => s.update());
    scene.reset();
  }

  function layout() {
    const W = canvas.width, H = canvas.height;
    const full = [0, 0, W, H];
    if (view.which === 'main') return { main: full };
    if (view.which === 'inspection') return { world: full };
    const k = W / canvas.clientWidth;
    const free = Math.max(400, panelRoot.getBoundingClientRect().left - canvas.getBoundingClientRect().left - 10) * k;
    const w = Math.floor(Math.min(free, W) / 2);
    const h = Math.min(H, Math.floor(w / 1.3));
    const y = Math.floor((H - h) / 2);
    return { world: [0, y, w, h], main: [w, y, w, h] };
  }

  function regionAt(px) {
    const k = canvas.width / canvas.clientWidth;
    const L = layout();
    for (const name of ['world', 'main']) {
      const r = L[name];
      if (!r) continue;
      const x = px[0] * k - r[0], y = px[1] * k - r[1];
      if (x < 0 || y < 0 || x > r[2] || y > r[3]) continue;
      return { name, ndc: [(2 * x) / r[2] - 1, 1 - (2 * y) / r[3]], w: r[2] / k, h: r[3] / k, aspect: r[2] / r[3] };
    }
    return null;
  }

  /* -------------- input --------------- */
  let lastVP = null;
  let editingCurve = false;
  let active = null;
  attachPointer(canvas, {
    // TODO (Part C): orbit the camera on drag, zoom on wheel.
    // TODO (Part D): pick / drag control points on the painting.
    down(e) {
      active = regionAt(e.px);
      editingCurve = active?.name === 'main' && !!lastVP &&
        scene.curves.grab(active.ndc, lastVP, active.w, active.h);
    },
    drag(e) {
      if (!active) return;
      if (editingCurve) {
        const r = regionAt(e.px);
        if (!r || r.name !== 'main') return;
        const hit = pickPaintingPlane(camera, r.aspect, r.ndc);
        if (hit) scene.curves.dragTo(hit);
        return;
      }
      const o = active.name === 'main' ? orbit : insOrbit;
      o.azimuth -= e.dx * 0.005;
      o.elevation += e.dy * 0.005;
      o.elevation = Math.max(-1.5, Math.min(1.5, o.elevation));
      if (active.name === 'main') updateEye();
      else placeEye(inspection, insOrbit);
    },
    up() {
      editingCurve = false;
      active = null;
      scene.curves.release();
    },
    wheel(e) {
      const r = regionAt(e.px);
      if (!r) return;
      const o = r.name === 'main' ? orbit : insOrbit;
      o.radius *= 1 + e.delta * 0.001;
      o.radius = Math.max(0.4, Math.min(r.name === 'main' ? 8 : 20, o.radius));
      if (r.name === 'main') updateEye();
      else placeEye(inspection, insOrbit);
    },
  });

  /* ------------ render loop ----------- */
  let last = performance.now();
  function frame(now) {
    stats.begin(now);
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;

    scene.update(dt, now / 1000);

    const L = layout();
    const mainRect = L.main ?? L.world;
    const aspect = mainRect[2] / mainRect[3];
    const vp = viewProjection(camera, aspect, painting.aspect);
    lastVP = vp.fallback ? null : vp.matrix;

    const passes = [];
    if (L.world && !vp.fallback) {
      passes.push({ rect: L.world, matrix: viewProjection(inspection, L.world[2] / L.world[3]).matrix, world: true });
    }
    if (L.main || vp.fallback) passes.push({ rect: mainRect, matrix: vp.matrix, world: false });

    camStatus.set(vp.fallback
      ? `PLACEHOLDER view (no camera yet)\n${vp.missing}`
      : `view: ${view.which} · main camera = P · V (${camera.projection})`);
    camStatus.el.classList.toggle('warn', vp.fallback);
    camReadout.set(
      `eye    ${camera.eye.map((x) => x.toFixed(2)).join(', ')}\n` +
      `target ${camera.target.map((x) => x.toFixed(2)).join(', ')}\n` +
      `up     ${camera.up.join(', ')}\n` +
      `fovY ${(camera.fovY * 180 / Math.PI).toFixed(1)}°  near ${camera.near.toFixed(2)}  far ${camera.far.toFixed(1)}`
    );

    passes.forEach((v, i) => renderer.render((pass) => {
      const [x, y, w, h] = v.rect;
      pass.setViewport(x, y, w, h, 0, 1);
      pass.setScissorRect(x, y, w, h);
      painting.draw(pass, vp.fallback ? v.matrix : mat4.multiply(v.matrix, painting.model), renderer);
      scene.draw(pass, v.matrix);
      if (v.world && view.frustum) {
        scene.mesh.drawLines(pass, v.matrix, frustumLines(camera, aspect));
        const E = mat4.multiply(mat4.translate(...camera.eye), mat4.scale(0.06, 0.06, 0.06));
        scene.mesh.drawCube(pass, mat4.multiply(v.matrix, E), E, [1, 0.45, 0.1]);
      }
    }, i === 0));

    stats.end(renderer.stats);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

main().catch((e) => {
  console.error(e);
  showFatal(e.message ?? String(e));
});