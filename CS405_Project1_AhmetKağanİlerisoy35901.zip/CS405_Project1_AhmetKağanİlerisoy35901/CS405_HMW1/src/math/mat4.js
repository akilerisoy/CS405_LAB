/**
 * mat4 — 4×4 matrices for Parts A and C.
 *
 * CONVENTIONS (the tests check exactly these):
 *   • A matrix is a Float32Array(16) in COLUMN-MAJOR order — the layout WebGPU
 *     expects for a mat4x4f in a uniform buffer. Element (row r, column c)
 *     lives at index  c * 4 + r.  The translation of an affine matrix is
 *     therefore at indices 12, 13, 14.
 *   • Column vectors: a point p is transformed as  M · p.
 *     multiply(A, B) returns A·B, so B is applied FIRST.
 *   • Right-handed world space. Angles in RADIANS. A positive angle rotates
 *     counter-clockwise when you look down the axis towards the origin
 *     (rotateZ(π/2) takes +x to +y).
 *   • View space: the camera sits at the origin and looks down −z, +y is up.
 *   • Clip space is WebGPU's: after the divide by w, x and y are in [−1, 1]
 *     and z is in [0, 1] (near → 0, far → 1). NOT OpenGL's [−1, 1].
 *
 * No maths libraries (no gl-matrix, no Three.js). Tests: tests/mat4.test.js
 */
import {add, sub, dot, cross, length, normalize} from './vec3.js';

/* ------------------------------------------------------------- Part A ---- */

/** The 4×4 identity. */
export function identity() {
  return new Float32Array([
    1,0,0,0,
    0,1,0,0,
    0,0,1,0,
    0,0,0,1,
  ]);
}

/** A · B (apply B first, then A). Must not modify a or b. */
export function multiply(a, b) {
  const c = new Float32Array(16);
  for (let col = 0; col < 4; col++) {
    for (let row = 0; row < 4; row++) {
      let sum = 0;
      for (let k = 0; k < 4; k++) {
        sum += a[k * 4 + row] * b[col * 4 + k];
      }
      c[col * 4 + row] = sum;
    }
  }
  return c;
}

/** Translation by (tx, ty, tz). */
export function translate(tx, ty, tz) {
    return new Float32Array([
    1,0,0,0,
    0,1,0,0,
    0,0,1,0,
    tx,ty,tz,1,
  ]);
}

/** Rotation by `rad` about the x axis. */
export function rotateX(rad) {
  const c = Math.cos(rad);
  const s = Math.sin(rad);
  return new Float32Array([
    1,0,0,0,
    0,c,s,0,
    0,-s,c,0,
    0,0,0,1,
  ]);
}

/** Rotation by `rad` about the y axis. */
export function rotateY(rad) {
  const c = Math.cos(rad);
  const s = Math.sin(rad);
  return new Float32Array([
    c,0,-s,0,
    0,1,0,0,
    s,0,c,0,
    0,0,0,1,
  ]);
}

/** Rotation by `rad` about the z axis. */
export function rotateZ(rad) {
  const c = Math.cos(rad);
  const s = Math.sin(rad);
  return new Float32Array([
    c,s,0,0,
    -s,c,0,0,
    0,0,1,0,
    0,0,0,1,
  ]);
}

/** Non-uniform scale by (sx, sy, sz). */
export function scale(sx, sy, sz) { 
    return new Float32Array([
    sx,0,0,0,
    0,sy,0,0,
    0,0,sz,0,
    0,0,0,1,
  ]);
}

/** Mᵀ */
export function transpose(m) {
  const transpose_M = new Float32Array(16);
  for (let col = 0; col < 4; col++) {
    for (let row = 0; row < 4; row++) {
      transpose_M[col * 4 + row] = m[row * 4 + col]
    }
  }
  return transpose_M;
}

/**
 * Inverse of a RIGID transform M = T·R (rotation + translation only, no scale).
 * Do not write a general 4×4 inverse: use the structure (Week 3).
 */
export function invertRigid(m) {
  const copy = new Float32Array(m);
  copy[12] = 0;
  copy[13] = 0;
  copy[14] = 0;
  const RT = transpose(copy);
  const RTt = transformVec4( RT, [m[12],m[13],m[14],0]);
  RT[12] = -RTt[0]; 
  RT[13] = -RTt[1];
  RT[14] = -RTt[2];
  return RT;
}

/** M · v for a 4-component v = [x, y, z, w]; returns [x', y', z', w']. */
export function transformVec4(m, v) {
  const matrixVecDot = [0,0,0,0];
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 4; col++) {
      matrixVecDot[row] += m[col * 4 + row] * v[col];
    }
  }
  return matrixVecDot;
}

/* ------------------------------------------------------------- Part C ---- */

/**
 * View matrix for a camera at `eye` looking at `target`, with `up` as the
 * approximate up direction. Build the camera basis with two cross products.
 * Must stay finite when `up` is parallel to the view direction — handle it.
 * eye, target, up: [x, y, z]
 */
export function lookAt(eye, target, up) {
  const w = normalize(sub(target,eye));

  let newUp = up;   // if up is parallel to the view direction
  if (length(cross(w,up)) <0.0001){
    if(Math.abs(w[1]) > 0.9) {
      newUp = [0,0,1];  // up changes direction
    }
    else {
      newUp = [0,1,0];  // stays the same 
    }
  }
  const u = normalize(cross(w,newUp));
  const v = cross(u,w);

  const cameraMatrix = new Float32Array([
    u[0],u[1],u[2],0,
    v[0],v[1],v[2],0,
    -w[0],-w[1],-w[2],0,
    eye[0],eye[1],eye[2],1,
  ]);

  return invertRigid(cameraMatrix);
}

/**
 * Perspective projection for WebGPU (depth z ∈ [0, 1]).
 * fovY: vertical field of view in radians; aspect = width / height;
 * near, far: positive distances along −z.
 */
export function perspective(fovY, aspect, near, far) { 
  const f = 1 / Math.tan(fovY/2);
  const A = far / (near-far)
  const B = (near * far) / (near-far)

  return new Float32Array([
    f/aspect,0,0,0,
    0,f,0,0,
    0,0,A,-1,
    0,0,B,0,
  ]);
}

/**
 * Orthographic projection for WebGPU (depth z ∈ [0, 1]) of the box
 * x ∈ [left, right], y ∈ [bottom, top], z ∈ [−near, −far] in view space.
 */
export function orthographic(left, right, bottom, top, near, far) {
  const sx = 2 / (right - left);
  const tx = -(right + left) / (right - left);
  const sy = 2 / (top - bottom);
  const ty = -(top + bottom) / (top - bottom);
  const sz = 1 / (near - far);
  const tz = near / (near - far);
  return new Float32Array([
    sx,0,0,0,
    0,sy,0,0,
    0,0,sz,0,
    tx,ty,tz,1,
  ]);
}

/* ------------------------------------------------- provided (not graded) - */

/**
 * Pretty-print a column-major matrix as four rows, for showing matrices on
 * screen (Part A asks you to display T·R·S and S·R·T).
 */
export function format(m, digits = 2) {
  if (!m) return '(none)';
  const w = digits + 4;
  let s = '';
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) s += (+m[c * 4 + r]).toFixed(digits).padStart(w);
    if (r < 3) s += '\n';
  }
  return s;
}
