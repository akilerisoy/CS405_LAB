/**
 * vec3 — 3-component vectors as plain arrays [x, y, z].
 *
 * Every function returns a NEW array and never modifies its arguments.
 * Write these yourself (Week 1, Linear Algebra I). Tests: tests/vec3.test.js
 */
import { todo } from './todo.js';

/** a + b */
export function add(a, b) { 
    const c = [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
    return c;
}

/** a − b */
export function sub(a, b) { 
    const c = [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
    return c;
}

/** s · a  (s is a number) */
export function scale(a, s) { 
    const c = [s * a[0], s * a[1], s * a[2]];
    return c;
}

/** a · b  → number */
export function dot(a, b) { 
    const c = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    return c;
}

/** a × b  (right-handed: cross([1,0,0],[0,1,0]) = [0,0,1]) */
export function cross(a, b) { 
    const c = [a[1]*b[2] - b[1]*a[2], a[2]*b[0] - b[2]*a[0], a[0]*b[1] - b[0]*a[1]]
    return c ; 
}

/** |a|  → number */
export function length(a) { 
    const c = Math.sqrt(a[1]*a[1] +  a[2]*a[2] + a[0]*a[0]); // I could have used dot(a,a)
    return c;
}

/**
 * a / |a|.
 * For a zero-length vector return [0, 0, 0] — never NaN.
 */
export function normalize(a) { 
    const len = length(a);
    if (len == 0) {
        return [0,0,0];
    }
    else {
        const c = [a[0]/len,a[1]/len,a[2]/len];
        return c;
    }
}
