import { todo } from './todo.js';

const lerp = (a, b, t) => a.map((x, i) => x + (b[i] - x) * t);
const combine = (pts, w) => pts[0].map((_, i) => pts.reduce((s, p, k) => s + w[k] * p[i], 0));

/* ---------------------------------------------------------- Bézier ------ */

/** The four cubic Bernstein basis values [B0(t), B1(t), B2(t), B3(t)]. */
export function bernstein3(t) {
  const u = 1 - t;
  return [u * u * u, 3 * u * u * t, 3 * u * t * t, t * t * t];
}

/** Point on the cubic Bézier curve with control points p0..p3 at t ∈ [0, 1]. */
export function cubicBezier(p0, p1, p2, p3, t) {
  return combine([p0, p1, p2, p3], bernstein3(t));
}

/** First derivative dB/dt of the cubic Bézier at t (not normalised). */
export function cubicBezierTangent(p0, p1, p2, p3, t) {
  const u = 1 - t;
  const w = [-3 * u * u, 3 * u * u - 6 * u * t, 6 * u * t - 3 * t * t, 3 * t * t];
  return combine([p0, p1, p2, p3], w);
}

/**
 * de Casteljau's construction for any number of control points.
 * Returns every level, for drawing the construction:
 *   levels[0] = the input points (n points)
 *   levels[1] = n − 1 interpolated points
 *   …
 *   levels[n − 1] = [the point on the curve]
 */
export function deCasteljau(points, t) {
  const levels = [points.map((p) => [...p])];
  while (levels[levels.length - 1].length > 1) {
    const prev = levels[levels.length - 1];
    const next = [];
    for (let i = 0; i + 1 < prev.length; i++) next.push(lerp(prev[i], prev[i + 1], t));
    levels.push(next);
  }
  return levels;
}

/* ----------------------------------------------- piecewise, C¹ joints --- */

/**
 * Given the last two control points P2, P3 of one segment, return the P1 of
 * the NEXT segment that makes the joint at P3 C¹-continuous.
 */
export function c1NextControl(p2, p3) {
  return p3.map((x, i) => 2 * x - p2[i]);
}

export function piecewiseLocal(n, u) {
  const s = Math.min(Math.max(u, 0), 1) * n;
  const i = Math.min(n - 1, Math.floor(s));
  return { i, t: s - i };
}

/**
 * Evaluate a piecewise cubic Bézier at a global parameter u ∈ [0, 1] that
 * runs over the whole curve: with n segments, segment i covers
 * u ∈ [i/n, (i+1)/n]. u = 0 is the first P0, u = 1 the last P3.
 */
export function evalPiecewise(segments, u) {
  const { i, t } = piecewiseLocal(segments.length, u);
  return cubicBezier(...segments[i], t);
}

export function tangentPiecewise(segments, u) {
  const { i, t } = piecewiseLocal(segments.length, u);
  return cubicBezierTangent(...segments[i], t);
}

/* ---------------------------- second curve family: implement ONE -------- */
/* The tests skip whichever of the two you leave as a TODO, and fail only   */
/* if you implement neither.                                                */

/**
 * Uniform Catmull–Rom: the segment between p1 and p2 (passes through both),
 * t ∈ [0, 1], with tangents (p2 − p0)/2 at p1 and (p3 − p1)/2 at p2.
 */
export function catmullRom(p0, p1, p2, p3, t) {
  const t2 = t * t, t3 = t2 * t;
  const w = [
    0.5 * (-t3 + 2 * t2 - t),
    0.5 * (3 * t3 - 5 * t2 + 2),
    0.5 * (-3 * t3 + 4 * t2 + t),
    0.5 * (t3 - t2),
  ];
  return combine([p0, p1, p2, p3], w);
}

export function evalCatmullRomSpline(points, u) {
  const n = points.length - 1;
  const { i, t } = piecewiseLocal(n, u);
  const P = (k) => points[Math.max(0, Math.min(n, k))];
  return catmullRom(P(i - 1), P(i), P(i + 1), P(i + 2), t);
}

/** Uniform cubic B-spline basis values [N0(t), N1(t), N2(t), N3(t)]. */
export function bsplineBasis(t) { return todo('curves.bsplineBasis'); }

/** Point on the uniform cubic B-spline segment controlled by p0..p3. */
export function bspline(p0, p1, p2, p3, t) { return todo('curves.bspline'); }