import meshWGSL from './shaders/mesh.wgsl?raw';
import lineWGSL from './shaders/line.wgsl?raw';
import { createShader, fragmentConstants } from './shader.js';
import { DEPTH_FORMAT } from './renderer.js';
import { cube, axes, cylinder } from '../scene/geometry.js';

export class MeshRenderer {
  constructor(gpu, renderer) {
    const { device } = gpu;
    this.gpu = gpu;
    this.renderer = renderer;

    this.cubeVertices = this.vertexBuffer(cube());
    this.cubeCount = 36;
    const cyl = cylinder(32);
    this.cylVertices = this.vertexBuffer(cyl);
    this.cylCount = cyl.length / 6;
    this.axesVertices = this.vertexBuffer(axes(1));
    this.axesCount = 6;

    this.meshLayout = device.createBindGroupLayout({
      entries: [{ binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } }],
    });
    this.lineLayout = device.createBindGroupLayout({
      entries: [{ binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'uniform' } }],
    });

    const meshModule = createShader(device, meshWGSL, 'mesh');
    const lineModule = createShader(device, lineWGSL, 'line');

    this.meshPipeline = this.pipeline(this.meshLayout, meshModule, 'triangle-list', false);
    this.listPipeline = this.pipeline(this.lineLayout, lineModule, 'line-list', false);
    this.stripPipeline = this.pipeline(this.lineLayout, lineModule, 'line-strip', false);
    this.axesPipeline = this.pipeline(this.lineLayout, lineModule, 'line-list', true);

    this.meshSlots = [];
    this.lineSlots = [];
    this.meshUsed = 0;
    this.lineUsed = 0;
  }

  pipeline(bindLayout, module, topology, onTop) {
    return this.gpu.device.createRenderPipeline({
      layout: this.gpu.device.createPipelineLayout({ bindGroupLayouts: [bindLayout] }),
      vertex: {
        module, entryPoint: 'vs',
        buffers: [{
          arrayStride: 6 * 4,
          attributes: [
            { shaderLocation: 0, offset: 0, format: 'float32x3' },
            { shaderLocation: 1, offset: 3 * 4, format: 'float32x3' },
          ],
        }],
      },
      fragment: {
        module, entryPoint: 'fs',
        targets: [{ format: this.gpu.viewFormat }],
        constants: fragmentConstants(this.gpu),
      },
      primitive: { topology, cullMode: 'none' },
      depthStencil: { format: DEPTH_FORMAT, depthWriteEnabled: !onTop, depthCompare: onTop ? 'always' : 'less' },
    });
  }

  vertexBuffer(data) {
    const buffer = this.gpu.device.createBuffer({
      size: data.byteLength,
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
    });
    this.gpu.device.queue.writeBuffer(buffer, 0, data);
    return buffer;
  }

  slot(list, used, layout, size) {
    if (used === list.length) {
      const uniforms = this.gpu.device.createBuffer({
        size,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
      });
      const bindGroup = this.gpu.device.createBindGroup({
        layout,
        entries: [{ binding: 0, resource: { buffer: uniforms } }],
      });
      list.push({ uniforms, bindGroup, vertices: null, capacity: 0 });
    }
    return list[used];
  }

  beginFrame() {
    this.meshUsed = 0;
    this.lineUsed = 0;
  }

  drawCube(pass, mvp, model, colour) {
    this.drawSolid(pass, mvp, model, colour, this.cubeVertices, this.cubeCount);
  }

  drawCylinder(pass, mvp, model, colour) {
    this.drawSolid(pass, mvp, model, colour, this.cylVertices, this.cylCount);
  }

  drawSolid(pass, mvp, model, colour, vertices, count) {
    const s = this.slot(this.meshSlots, this.meshUsed++, this.meshLayout, 144);
    const data = new Float32Array(36);
    data.set(mvp, 0);
    data.set(model, 16);
    data.set([colour[0], colour[1], colour[2], 1], 32);
    this.gpu.device.queue.writeBuffer(s.uniforms, 0, data);
    pass.setPipeline(this.meshPipeline);
    pass.setBindGroup(0, s.bindGroup);
    pass.setVertexBuffer(0, vertices);
    pass.draw(count);
    this.renderer.countDraw(count);
  }

  drawAxes(pass, mvp) {
    const s = this.slot(this.lineSlots, this.lineUsed++, this.lineLayout, 64);
    this.gpu.device.queue.writeBuffer(s.uniforms, 0, mvp);
    pass.setPipeline(this.axesPipeline);
    pass.setBindGroup(0, s.bindGroup);
    pass.setVertexBuffer(0, this.axesVertices);
    pass.draw(this.axesCount);
    this.renderer.countDraw(this.axesCount);
  }

  drawLines(pass, mvp, data, strip = false) {
    const count = data.length / 6;
    if (count < 2) return;
    const s = this.slot(this.lineSlots, this.lineUsed++, this.lineLayout, 64);
    if (data.byteLength > s.capacity) {
      s.vertices?.destroy();
      s.capacity = Math.max(data.byteLength, 1536);
      s.vertices = this.gpu.device.createBuffer({
        size: s.capacity,
        usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
      });
    }
    this.gpu.device.queue.writeBuffer(s.uniforms, 0, mvp);
    this.gpu.device.queue.writeBuffer(s.vertices, 0, data);
    pass.setPipeline(strip ? this.stripPipeline : this.listPipeline);
    pass.setBindGroup(0, s.bindGroup);
    pass.setVertexBuffer(0, s.vertices);
    pass.draw(count);
    this.renderer.countDraw(count);
  }
}