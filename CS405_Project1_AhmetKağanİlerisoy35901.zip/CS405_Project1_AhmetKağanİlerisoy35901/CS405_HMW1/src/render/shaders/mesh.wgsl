// Solid, lit meshes (cubes etc.). Used by render/mesh.js.
// Vertex data: position (xyz) + normal (xyz), 24 bytes per vertex.
// toOutput() comes from colour.wgsl, prepended by createShader().

struct Uniforms {
  mvp:    mat4x4f,  // P · V · M   : object space → clip space
  model:  mat4x4f,  // M           : object space → world space (for the normal)
  colour: vec4f,    // LINEAR rgb + alpha
};

@group(0) @binding(0) var<uniform> u: Uniforms;

struct VSOut {
  @builtin(position) position: vec4f,
  @location(0) normal: vec3f,   // world-space normal, interpolated across the triangle
};

@vertex
fn vs(@location(0) pos: vec3f, @location(1) normal: vec3f) -> VSOut {
  var o: VSOut;
  o.position = u.mvp * vec4f(pos, 1.0);            // p_clip = P·V·M·p
  // A normal is a direction, so w = 0: the translation in M must not move it.
  // (Exact for rotations and uniform scale; non-uniform scale would need the
  //  inverse-transpose of M, which is close enough for flat-shaded boxes.)
  o.normal = (u.model * vec4f(normal, 0.0)).xyz;
  return o;
}

@fragment
fn fs(i: VSOut) -> @location(0) vec4f {
  let n = normalize(i.normal);
  let lightDir = normalize(vec3f(0.4, 0.8, 0.6));  // fixed light, from upper front right
  let diffuse = max(dot(n, lightDir), 0.0);        // Lambert: brightest when facing the light
  let ambient = 0.25;                              // so faces in shadow are not pure black
  let c = u.colour.rgb * (ambient + (1.0 - ambient) * diffuse);
  return toOutput(vec4f(c, u.colour.a));
}