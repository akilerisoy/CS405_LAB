import * as mat4 from '../math/mat4.js';
import * as curves from '../math/curves.js';
import { curveToJSON, downloadJSON } from './curveExport.js';

const LIFT = 0.01;
const GRAB_PX = 14;

const START_UV = [
  [0.38, 0.86], [0.40, 0.78], [0.43, 0.70],
  [0.45, 0.62], [0.47, 0.54], [0.51, 0.45],
  [0.56, 0.40], [0.61, 0.35], [0.67, 0.22],
  [0.73, 0.11],
];

export function createCurveEditor({ mesh, panel, painting, paintingId }) {
  const uvToWorld = ([u, v]) => [(2 * u - 1) * painting.aspect, 1 - 2 * v];

  const state = {
    kind: 'bezier-c1',
    t: 0.35,
    animate: true,
    speed: 0.08,
    showPolygon: true,
    showCasteljau: true,
  };
  let pts = START_UV.map(uvToWorld);
  let grabbed = -1;

  const isKnot = (i) => i % 3 === 0;
  const knots = () => pts.filter((_, i) => isKnot(i));
  const segments = () => {
    const s = [];
    for (let i = 0; i + 3 < pts.length; i += 3) s.push([pts[i], pts[i + 1], pts[i + 2], pts[i + 3]]);
    return s;
  };

  function evaluate(u) {
    if (state.kind === 'catmull-rom') {
      const K = knots();
      const h = 1e-3;
      const a = curves.evalCatmullRomSpline(K, Math.max(0, u - h));
      const b = curves.evalCatmullRomSpline(K, Math.min(1, u + h));
      return { p: curves.evalCatmullRomSpline(K, u), d: [b[0] - a[0], b[1] - a[1]] };
    }
    const S = segments();
    return { p: curves.evalPiecewise(S, u), d: curves.tangentPiecewise(S, u) };
  }

  function enforceC1(moved) {
    if (state.kind !== 'bezier-c1') return;
    for (let k = 3; k < pts.length - 1; k += 3) {
      const K = pts[k];
      if (moved === k - 1) pts[k + 1] = curves.c1NextControl(pts[k - 1], K);
      else if (moved === k + 1) pts[k - 1] = curves.c1NextControl(pts[k + 1], K);
    }
  }

  const f = panel.folder('Part D · Curves');
  f.select('curve', [
    { value: 'bezier-c1', label: 'Bezier' },
    { value: 'catmull-rom', label: 'Catmull-Rom' },
  ], state.kind, (v) => (state.kind = v));
  const tSlider = f.slider('t', state, 't', 0, 1, 0.001);
  const animToggle = f.toggle('animate along curve', state, 'animate');
  f.slider('speed', state, 'speed', 0.01, 0.4, 0.01);
  f.toggle('control polygon', state, 'showPolygon');
  f.toggle('de Casteljau at t', state, 'showCasteljau');
  f.note('Drag the points on the painting. Drag anywhere else to orbit.');
  f.button('add segment', addSegment);
  f.button('remove segment', removeSegment);
  f.button('reset curve', reset);
  f.button('export JSON', () => downloadJSON(toJSON(), `curve-${paintingId()}.json`));
  const readout = f.text('');

  function addSegment() {
    const n = pts.length;
    const K = pts[n - 1], H = pts[n - 2];
    const dir = [K[0] - H[0], K[1] - H[1]];
    const h1 = curves.c1NextControl(H, K);
    pts.push(h1, [h1[0] + dir[0], h1[1] + dir[1]], [h1[0] + 2 * dir[0], h1[1] + 2 * dir[1] - 0.1]);
  }
  function removeSegment() {
    if (pts.length > 10) pts.splice(pts.length - 3, 3);
  }
  function reset() {
    pts = START_UV.map(uvToWorld);
    Object.assign(state, { kind: 'bezier-c1', t: 0.35, animate: true, speed: 0.08, showPolygon: true, showCasteljau: true });
    tSlider.update(); animToggle.update();
  }
  function toJSON() {
    return curveToJSON({
      painting: paintingId(),
      kind: state.kind,
      aspect: painting.aspect,
      points: state.kind === 'catmull-rom' ? knots() : pts,
    });
  }

  function grab(ndc, viewProj, cssW, cssH) {
    grabbed = -1;
    let best = GRAB_PX * GRAB_PX;
    pts.forEach((p, i) => {
      if (state.kind === 'catmull-rom' && !isKnot(i)) return;
      const c = mat4.transformVec4(viewProj, [p[0], p[1], LIFT, 1]);
      if (c[3] <= 0) return;
      const dx = (c[0] / c[3] - ndc[0]) * cssW / 2;
      const dy = (c[1] / c[3] - ndc[1]) * cssH / 2;
      if (dx * dx + dy * dy < best) { best = dx * dx + dy * dy; grabbed = i; }
    });
    return grabbed >= 0;
  }

  function dragTo(hit) {
    if (grabbed < 0) return;
    const old = pts[grabbed];
    if (isKnot(grabbed)) {
      const dx = hit[0] - old[0], dy = hit[1] - old[1];
      for (const j of [grabbed - 1, grabbed + 1]) {
        if (pts[j] && !isKnot(j)) pts[j] = [pts[j][0] + dx, pts[j][1] + dy];
      }
    }
    pts[grabbed] = [hit[0], hit[1]];
    enforceC1(grabbed);
  }

  function release() { grabbed = -1; }

  function update(dt) {
    if (state.animate) {
      state.t = (state.t + dt * state.speed) % 1;
      tSlider.update();
    }
    const { p } = evaluate(state.t);
    const nSeg = state.kind === 'catmull-rom' ? knots().length - 1 : segments().length;
    const u = (p[0] / painting.aspect + 1) / 2, v = (1 - p[1]) / 2;
    readout.set(
      `${state.kind}  ·  ${nSeg} segments\n` +
      `t = ${state.t.toFixed(3)}\n` +
      `C(t) world (${p[0].toFixed(3)}, ${p[1].toFixed(3)})\n` +
      `C(t) u,v   (${u.toFixed(3)}, ${v.toFixed(3)})`
    );
  }

  const line = (points, rgb, z = LIFT) => {
    const out = new Float32Array(points.length * 6);
    points.forEach((p, i) => out.set([p[0], p[1], z, ...rgb], i * 6));
    return out;
  };

  function draw(pass, viewProj) {
    const N = 240, samples = [];
    for (let k = 0; k <= N; k++) samples.push(evaluate(k / N).p);
    mesh.drawLines(pass, viewProj, line(samples, [1.0, 0.75, 0.05], LIFT + 0.002), true);

    if (state.kind === 'bezier-c1') {
      if (state.showPolygon) mesh.drawLines(pass, viewProj, line(pts, [0.7, 0.7, 0.7]), true);

      if (state.showCasteljau) {
        const { i, t } = curves.piecewiseLocal(segments().length, state.t);
        const levels = curves.deCasteljau(segments()[i], t);
        const cols = [[0.25, 0.6, 1.0], [0.3, 0.85, 0.35], [1.0, 0.35, 0.2]];
        for (let L = 1; L < levels.length; L++) {
          mesh.drawLines(pass, viewProj, line(levels[L], cols[L - 1], LIFT + 0.004), true);
          for (const q of levels[L]) dot(pass, viewProj, q, 0.012, cols[L - 1]);
        }
      }
    }

    pts.forEach((p, i) => {
      if (state.kind === 'catmull-rom' && !isKnot(i)) return;
      const hot = i === grabbed;
      dot(pass, viewProj, p, isKnot(i) ? 0.035 : 0.024,
        hot ? [1, 1, 0.2] : isKnot(i) ? [0.9, 0.3, 0.08] : [0.95, 0.95, 0.95]);
    });

    const { p, d } = evaluate(state.t);
    const M = mat4.multiply(mat4.translate(p[0], p[1], 0.03), mat4.rotateZ(Math.atan2(d[1], d[0])));
    const body = mat4.multiply(M, mat4.scale(0.09, 0.065, 0.04));
    const head = mat4.multiply(M, mat4.multiply(mat4.translate(0.055, 0, 0), mat4.scale(0.03, 0.04, 0.035)));
    mesh.drawCube(pass, mat4.multiply(viewProj, body), body, [0.75, 0.05, 0.03]);
    mesh.drawCube(pass, mat4.multiply(viewProj, head), head, [0.03, 0.03, 0.03]);
  }

  function dot(pass, viewProj, p, size, colour) {
    const M = mat4.multiply(mat4.translate(p[0], p[1], LIFT), mat4.scale(size, size, size));
    mesh.drawCube(pass, mat4.multiply(viewProj, M), M, colour);
  }

  return { state, grab, dragTo, release, update, draw, reset, toJSON };
}