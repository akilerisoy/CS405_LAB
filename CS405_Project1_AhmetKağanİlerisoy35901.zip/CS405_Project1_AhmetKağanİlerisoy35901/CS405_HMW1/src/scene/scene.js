/**
 * YOUR SCENE — Parts A, B and D live here (and in files you add next to it).
 *
 * main.js calls, every frame:
 *     scene.update(dt, time)          dt and time in seconds
 *     scene.draw(pass, viewProj)      inside the frame's render pass
 * and scene.reset() from the panel's "reset" button.
 *
 * Suggested steps
 *   Part A  Write a small mesh pipeline (copy the structure of
 *           render/painting.js: vertex buffer → uniform buffer → bind group
 *           → pipeline → draw). Use geometry.js for cube data. Place at least
 *           three objects in front of the painting (z > 0) with YOUR mat4.
 *   Part B  Build a SceneNode tree (scene/node.js), call root.updateWorld()
 *           in update(), and draw every node with  viewProj · node.world.
 *   Part D  Draw control points and the curve over the painting
 *           (topology 'line-strip' or 'point-list' works for a start).
 *
 * WebGPU gotcha: queue.writeBuffer() calls all run BEFORE the frame's
 * commands execute. If several objects share ONE uniform buffer, they all
 * see the last value written. Give each object its own uniform buffer (or
 * its own slice of a big one, with a dynamic offset).
 *
 * Call renderer.countDraw(vertexCount) after each draw so the vertex
 * counter in the panel is correct (Part E).
 */

import { MeshRenderer } from '../render/mesh.js';
import * as mat4 from '../math/mat4.js';
import { SceneNode } from './node.js';
import { createCurveEditor } from './curveEditor.js';

const DEFAULTS = {
  debugAxes: false,
  tx: 0.25, ty: -0.55, tz: 0.6,
  angle: 0,
  s: 0.2,
  trs: true,
  animate: true,
  base: 0,
  joint1: 0,
  joint2: -0.4,
};

export function createScene({ gpu, renderer, painting, panel, paintingId }) {
  const mesh = new MeshRenderer(gpu, renderer);
  const state = { ...DEFAULTS };

  // Example of wiring a control. Add a folder per part as you go.
  const f = panel.folder('Scene');
  const axesToggle = f.toggle('debug axes', state, 'debugAxes');
  const a = panel.folder('Part A');
  const aSliders = [
    a.slider('x', state, 'tx', -1.2, 1.2, 0.01),
    a.slider('y', state, 'ty', -1, 1, 0.01),
    a.slider('z', state, 'tz', 0, 1.5, 0.01),
    a.slider('angle', state, 'angle', -Math.PI, Math.PI, 0.01),
    a.slider('scale', state, 's', 0.05, 0.6, 0.01),
  ];
  const trsToggle = a.toggle('T·R·S (off = S·R·T)', state, 'trs');
  const trsText = a.text();
  const srtText = a.text();

  const b = panel.folder('Part B');
  const animToggle = b.toggle('Animate Gull and Flag', state, 'animate');
  const treeSliders = [
    b.slider('tree base (Ry)', state, 'base', -Math.PI, Math.PI, 0.01),
    b.slider('joint 1 (Rz)', state, 'joint1', -0.5, 0.9, 0.01),
    b.slider('joint 2 (Rz)', state, 'joint2', -1.2, 1.2, 0.01),
  ];
  
  const wingText = b.text();

  const box = (size, colour, offset = [0, 0, 0]) => ({ size, colour, offset });
  const cyl = (size, colour, offset = [0, 0, 0]) => ({ size, colour, offset, cylinder: true });

  const root = new SceneNode('root');

  const tree = root.addChild(new SceneNode('tree'));
  tree.data.parts = [box([0.06, 0.45, 0.06], [0.35, 0.22, 0.1], [0, 0.225, 0])];
  const branch = (name, side) => {
    const n = tree.addChild(new SceneNode(name));
    n.data.side = side;
    n.data.parts = [box([0.03, 0.18, 0.03], [0.35, 0.22, 0.1], [0, 0.09, 0])];
    const twig = n.addChild(new SceneNode(name + '-twig'));
    twig.data.parts = [box([0.024, 0.14, 0.024], [0.4, 0.27, 0.12], [0, 0.07, 0])];
    const leaf = twig.addChild(new SceneNode(name + '-leaf', mat4.translate(0, 0.14, 0)));
    leaf.data.parts = [box([0.1, 0.2, 0.08], [0.22, 0.52, 0.13], [0, 0.08, 0])];
    return n;
  };
  const branchL = branch('branchL', 1);
  const branchR = branch('branchR', -1);

  const crate = root.addChild(new SceneNode('crate', mat4.translate(-0.5, -0.7, 0.4)));
  crate.data.parts = [box([0.14, 0.14, 0.14], [0.55, 0.36, 0.16], [0, 0.07, 0])];

  const bin = root.addChild(new SceneNode('bin', mat4.translate(-0.25, -0.7, 0.35)));
  bin.data.parts = [cyl([0.11, 0.18, 0.11], [0.25, 0.3, 0.32], [0, 0.09, 0])];

  const boat = root.addChild(new SceneNode('boat', mat4.translate(0.8, -0.66, 0.35)));
  boat.data.parts = [
    box([0.32, 0.06, 0.12], [0.45, 0.22, 0.08]),
    box([0.1, 0.06, 0.08], [0.9, 0.88, 0.82], [-0.06, 0.06, 0]),
  ];
  const mast = boat.addChild(new SceneNode('mast', mat4.translate(0.06, 0.03, 0)));
  mast.data.parts = [box([0.012, 0.26, 0.012], [0.3, 0.2, 0.1], [0, 0.13, 0])];
  const flag = mast.addChild(new SceneNode('flag'));
  flag.data.parts = [box([0.09, 0.055, 0.005], [0.8, 0.08, 0.06], [0.045, 0, 0])];

  const gullPivot = root.addChild(new SceneNode('gullPivot'));
  const gull = gullPivot.addChild(new SceneNode('gull', mat4.multiply(mat4.translate(0.22, 0.3, 0), mat4.scale(1.3, 1.3, 1.3))));
  gull.data.parts = [box([0.04, 0.03, 0.12], [0.9, 0.9, 0.88])];
  const beak = gull.addChild(new SceneNode('beak', mat4.translate(0, 0, -0.07)));
  beak.data.parts = [box([0.012, 0.01, 0.03], [0.85, 0.6, 0.1])];
  const leftWing = gull.addChild(new SceneNode('leftWing'));
  leftWing.data.parts = [box([0.12, 0.008, 0.06], [0.75, 0.76, 0.78], [-0.06, 0, 0])];
  const rightWing = gull.addChild(new SceneNode('rightWing'));
  rightWing.data.parts = [box([0.12, 0.008, 0.06], [0.75, 0.76, 0.78], [0.06, 0, 0])];

  const curves = createCurveEditor({ mesh, panel, painting, paintingId });

  function partA() {
    const T = mat4.translate(state.tx, state.ty, state.tz);
    const R = mat4.rotateY(state.angle);
    const S = mat4.scale(state.s, state.s, state.s);
    const TRS = mat4.multiply(T, mat4.multiply(R, S));
    const SRT = mat4.multiply(S, mat4.multiply(R, T));
    return { TRS, SRT, M: state.trs ? TRS : SRT };
  }

  return {
    state,
    curves,
    root,
    mesh,

    update(dt, time) {
      // TODO: animate nodes, then root.updateWorld()
      const t = state.animate ? time : 0;

      tree.local = mat4.multiply(mat4.translate(-0.78, -0.7, 0.3), mat4.rotateY(state.base));
      for (const n of [branchL, branchR]) {
        const side = n.data.side;
        n.local = mat4.multiply(mat4.translate(0, 0.42, 0), mat4.rotateZ(side * (0.7 + state.joint1)));
        n.children[0].local = mat4.multiply(mat4.translate(0, 0.18, 0), mat4.rotateZ(side * state.joint2));
      }

      flag.local = mat4.multiply(mat4.translate(0, 0.23, 0), mat4.rotateY(0.6 * Math.sin(t * 5)));

      gullPivot.local = mat4.multiply(mat4.translate(0.55, -0.3, 0.45), mat4.rotateY(t * 0.8));
      const flap = 0.5 * Math.sin(t * 8);
      leftWing.local = mat4.multiply(mat4.translate(-0.02, 0, 0), mat4.rotateZ(flap));
      rightWing.local = mat4.multiply(mat4.translate(0.02, 0, 0), mat4.rotateZ(-flap));

      root.updateWorld();
      curves.update(dt);

      const { TRS, SRT } = partA();
      trsText.set('T·R·S\n' + mat4.format(TRS));
      srtText.set('S·R·T\n' + mat4.format(SRT));
      wingText.set('root → gullPivot → gull → leftWing\n' + mat4.format(leftWing.world, 3));
    },

    /** @param {GPURenderPassEncoder} pass  @param {Float32Array} viewProj  P · V */
    draw(pass, viewProj) {
      mesh.beginFrame();

      root.traverse((node) => {
        for (const p of node.data.parts ?? []) {
          const M = mat4.multiply(node.world, mat4.multiply(mat4.translate(...p.offset), mat4.scale(...p.size)));
          if (p.cylinder) mesh.drawCylinder(pass, mat4.multiply(viewProj, M), M, p.colour);
          else mesh.drawCube(pass, mat4.multiply(viewProj, M), M, p.colour);
        }
      });

      const { M } = partA();
      mesh.drawCube(pass, mat4.multiply(viewProj, M), M, [0.9, 0.8, 0.2]);

      curves.draw(pass, viewProj);

      if (state.debugAxes) {
        root.traverse((node) => {
          const A = mat4.multiply(node.world, mat4.scale(0.1, 0.1, 0.1));
          mesh.drawAxes(pass, mat4.multiply(viewProj, A));
        });
      }
    },

    reset() {
      // TODO: put every object (and the camera, in main.js) back where it started
      Object.assign(state, DEFAULTS);
      [...aSliders, ...treeSliders].forEach((s) => s.update());
      [axesToggle, trsToggle, animToggle].forEach((t) => t.update());
      curves.reset();
    },
  };
}