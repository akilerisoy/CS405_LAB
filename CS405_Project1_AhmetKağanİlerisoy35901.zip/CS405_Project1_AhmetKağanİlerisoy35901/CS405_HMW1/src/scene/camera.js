/**
 * Camera — Part C.
 *
 * The camera is plain data. viewProjection() turns it into P · V using YOUR
 * mat4.lookAt / mat4.perspective / mat4.orthographic / mat4.multiply.
 *
 * Until those exist it falls back to a fixed "fit the painting to the window"
 * matrix, so the starter shows your painting from the first `npm run dev`.
 * The panel tells you which of the two is active.
 */
import * as mat4 from '../math/mat4.js';
import { NotImplemented } from '../math/todo.js';
import { add, sub, scale, cross, length, normalize } from '../math/vec3.js';

export function createCamera() {
  return {
    eye: [0, 0, 2.8],
    target: [0, 0, 0],
    up: [0, 1, 0],
    fovY: Math.PI / 4, // radians
    near: 0.1,
    far: 10,
    projection: 'perspective', // or 'orthographic'
    orthoHeight: 2.2, // world units visible vertically in orthographic mode
  };
}

/**
 * @param {object} cam     from createCamera()
 * @param {number} aspect  canvas width / height
 * @param {number} paintingAspect  image width / height (only used by the fallback)
 * @returns {{ matrix: Float32Array, fallback: boolean, missing?: string }}
 */
export function viewProjection(cam, aspect, paintingAspect = 1) {
  try {
    const view = mat4.lookAt(cam.eye, cam.target, cam.up);
    let proj;
    if (cam.projection === 'orthographic') {
      const h = cam.orthoHeight / 2, w = h * aspect;
      proj = mat4.orthographic(-w, w, -h, h, cam.near, cam.far);
    } else {
      proj = mat4.perspective(cam.fovY, aspect, cam.near, cam.far);
    }
    return { matrix: mat4.multiply(proj, view), fallback: false };
  } catch (e) {
    if (!(e instanceof NotImplemented)) throw e;
    return { matrix: fitMatrix(aspect, paintingAspect), fallback: true, missing: e.message };
  }
}

export function rayThroughNDC(cam, aspect, ndc) {
  const forward = normalize(sub(cam.target, cam.eye));
  let right = cross(forward, cam.up);
  if (length(right) < 1e-4) right = cross(forward, Math.abs(forward[1]) > 0.9 ? [0, 0, 1] : [0, 1, 0]);
  right = normalize(right);
  const up = cross(right, forward);

  if (cam.projection === 'orthographic') {
    const h = cam.orthoHeight / 2, w = h * aspect;
    const origin = add(cam.eye, add(scale(right, ndc[0] * w), scale(up, ndc[1] * h)));
    return { origin, dir: forward };
  }
  const th = Math.tan(cam.fovY / 2);
  const dir = normalize(add(forward, add(scale(right, ndc[0] * th * aspect), scale(up, ndc[1] * th))));
  return { origin: cam.eye, dir };
}

export function pickPaintingPlane(cam, aspect, ndc) {
  const { origin, dir } = rayThroughNDC(cam, aspect, ndc);
  if (Math.abs(dir[2]) < 1e-6) return null;
  const s = -origin[2] / dir[2];
  if (s < 0) return null;
  return [origin[0] + s * dir[0], origin[1] + s * dir[1]];
}

export function frustumCorners(cam, aspect) {
  const forward = normalize(sub(cam.target, cam.eye));
  let right = cross(forward, cam.up);
  if (length(right) < 1e-4) right = cross(forward, Math.abs(forward[1]) > 0.9 ? [0, 0, 1] : [0, 1, 0]);
  right = normalize(right);
  const up = cross(right, forward);

  const corners = [];
  for (const d of [cam.near, cam.far]) {
    const hh = cam.projection === 'orthographic' ? cam.orthoHeight / 2 : d * Math.tan(cam.fovY / 2);
    const hw = hh * aspect;
    const centre = add(cam.eye, scale(forward, d));
    for (const [sx, sy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
      corners.push(add(centre, add(scale(right, sx * hw), scale(up, sy * hh))));
    }
  }
  return corners;
}

export function frustumLines(cam, aspect) {
  const c = frustumCorners(cam, aspect);
  const NEAR = [1, 0.45, 0.1], FAR = [1, 0.8, 0.2], SIDE = [0.9, 0.6, 0.15], AXIS = [0.6, 0.6, 0.6];
  const v = [];
  const seg = (a, b, col) => v.push(...a, ...col, ...b, ...col);
  for (let k = 0; k < 4; k++) {
    seg(c[k], c[(k + 1) % 4], NEAR);
    seg(c[4 + k], c[4 + (k + 1) % 4], FAR);
    seg(c[k], c[4 + k], SIDE);
    seg(cam.eye, c[k], SIDE);
  }
  seg(cam.eye, cam.target, AXIS);
  return new Float32Array(v);
}

export function createInspectionCamera() {
  return { ...createCamera(), target: [0, -0.1, 1.3], fovY: 0.9, near: 0.1, far: 100 };
}

/**
 * Placeholder used until Part C works: scales the painting quad (height 2,
 * width 2·paintingAspect, centred at the origin in the z = 0 plane) to fit
 * the canvas, and maps world z to depth so that +z is in front.
 * There is no camera here — do not build on this.
 */
function fitMatrix(aspect, paintingAspect) {
  const s = 0.92 * Math.min(1, aspect / paintingAspect);
  return new Float32Array([
    s / aspect, 0, 0, 0,
    0, s, 0, 0,
    0, 0, -0.05, 0,
    0, 0, 0.5, 1,
  ]);
}