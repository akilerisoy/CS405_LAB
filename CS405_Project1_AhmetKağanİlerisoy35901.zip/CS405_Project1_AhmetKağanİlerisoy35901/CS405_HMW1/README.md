# CS405 Project 1: Transformations, Projection & Curves from Paintings

One WebGPU application that turns **Hoca Ali Rıza: Moda İskelesi** (Sakıp Sabancı Museum) into a small 3D scene. The painting hangs as a textured quad at z = 0. In front of it stand a tree with jointed branches, a crate, a bin, a boat with a waving flag and a gull circling over the water. A C¹ Bézier curve traces the leaning trunk of the large tree, and a second camera shows the main camera's frustum.

Plain JavaScript, WebGPU and WGSL only. All matrix, vector and curve maths is my own code in `src/math/`; no maths, scene-graph or 3D library is used.

## Running it

Requirements: Node.js 20.19 or newer and a browser with WebGPU (current Chrome or Edge, Safari 26+, or Firefox 141+ on Windows).

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # unit tests: 51 pass, 1 skipped (B-spline, not implemented)
```

The app opens on Moda İskelesi. Another painting can be chosen in the Painting folder, but the scene and the default curve are made for Moda.

## Mouse

| Action | Where | Effect |
|---|---|---|
| Drag a curve point | right half (camera view) or main view | moves that control point on the painting |
| Drag empty space | right half (camera view) or main view | orbits the main camera around its target |
| Drag | left half (world view) | orbits the second camera around the main camera's target; the main camera stays still |
| Wheel | either half | zooms the camera of that half |

## Panel controls

| Folder | Control | What it does |
|---|---|---|
| (top) | stats | frame time, CPU time, draw calls and vertices per frame |
| Painting | painting | switches the painting |
| View | view | **side by side** (default: world view left, main camera right), **main camera only**, **inspection camera only** |
| View | draw main camera frustum | shows the frustum, the eye (orange cube) and the target (white cube) in the world view |
| View | reset scene + camera | puts the cameras, every slider and the curve back to their starting values |
| Camera | projection | perspective or orthographic |
| Camera | fovY, near, far | the main camera's field of view (radians) and clip planes |
| Camera | readout | the main camera's eye, target, up, fovY, near and far |
| Scene | debug axes | draws the local x/y/z axes of every scene node |
| Part A | x, y, z, angle, scale | position, rotation about y and uniform scale of the yellow cube |
| Part A | T·R·S (off = S·R·T) | switches the composition order; both matrices are shown below it |
| Part B | Animate Gull and Flag | turns the gull's circling and flapping and the flag's waving on or off (off = time 0) |
| Part B | tree base (Ry), joint 1 (Rz), joint 2 (Rz) | turn the tree trunk, the branches at the trunk and the twigs at the elbow |
| Part B | readout | world matrix of root → gullPivot → gull → leftWing |
| Part D · Curves | curve | piecewise Bézier (C¹) or Catmull-Rom through the knots |
| Part D · Curves | t, animate along curve, speed | position of the ladybird on the curve, and its automatic motion |
| Part D · Curves | control polygon, de Casteljau at t | show the control polygon and the de Casteljau levels at t |
| Part D · Curves | add segment, remove segment | grow or shrink the curve by one Bézier segment, keeping C¹ |
| Part D · Curves | reset curve | restores the default traced shape |
| Part D · Curves | export JSON | downloads the curve as `curve-moda.json` in normalised painting coordinates |

The exported default curve is committed as `curve.json`.

## Code structure

| Path | Contents |
|---|---|
| `src/math/vec3.js`, `mat4.js` | vectors and column-major 4×4 matrices: multiply, translate, rotations, scale, transpose, rigid inverse, lookAt, perspective and orthographic (WebGPU depth 0..1) |
| `src/math/curves.js` | Bernstein basis, cubic Bézier and tangent, de Casteljau, C¹ control point, piecewise evaluation, Catmull-Rom |
| `src/scene/node.js` | scene graph node; `updateWorld()` computes world = parent.world · local |
| `src/scene/scene.js` | the scene: Part A cube, the node tree, animation, drawing, reset |
| `src/scene/camera.js` | camera data, view-projection, picking ray, frustum corners and lines, inspection camera |
| `src/scene/curveEditor.js` | curve state, mouse picking and dragging, drawing, ladybird, panel folder |
| `src/scene/curveExport.js` | curve → JSON in normalised (u, v) coordinates |
| `src/scene/geometry.js` | cube, axes and cylinder vertex data |
| `src/render/` | GPU setup, renderer (`render(draw, clear)` so two viewports can share a frame), painting and mesh pipelines, WGSL shaders |
| `src/ui/` | panel, stats, pointer input |
| `src/main.js` | wiring, orbit controls, view layouts and render loop |

Conventions: column vectors (p' = M·p), matrices stored column-major exactly as WGSL `mat4x4f` expects, right-handed world, camera looking down −z, clip-space depth in [0, 1].